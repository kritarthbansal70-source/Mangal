import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, Check, ChevronDown, ChevronUp, Copy, Download, KeyRound, LockKeyhole, Mail, Package, Phone, Plus, RotateCcw, Save, Settings, Trash2, Upload, X } from "lucide-react";
import { Dialog } from "./Dialog";
import type { Product } from "../lib/commerce";
import {
  configMailto, downloadConfigJson, formatPhone, isEmail, loadPin, newProductTemplate,
  resetConfig, sanitizeConfig, saveConfig, savePin, summarizeConfig, type ContactInfo, type SiteConfig,
} from "../lib/siteConfig";

type Tab = "products" | "contact" | "publish";

interface AdminPanelProps {
  open: boolean;
  config: SiteConfig;
  onClose: () => void;
  onApply: (config: SiteConfig) => void;
}

const inputCls = "w-full min-h-10 rounded border border-outline-variant bg-surface-container-lowest px-3 text-sm text-primary outline-none focus:border-tertiary focus:ring-2 focus:ring-tertiary/20";
const labelCls = "mb-1 block text-[11px] font-semibold text-on-surface-variant";

function Field({ label, value, onChange, type = "text", placeholder = "", hint }: {
  label: string; value: string | number; onChange: (v: string) => void; type?: string; placeholder?: string; hint?: string;
}) {
  return (
    <label className="block min-w-0">
      <span className={labelCls}>{label}</span>
      <input type={type} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} className={inputCls} step={type === "number" ? "any" : undefined} inputMode={type === "number" ? "decimal" : undefined} />
      {hint && <span className="mt-1 block text-[10px] text-outline">{hint}</span>}
    </label>
  );
}

function ProductEditor({ product, index, total, onChange, onRemove, onMove }: {
  product: Product; index: number; total: number;
  onChange: (p: Product) => void; onRemove: () => void; onMove: (dir: -1 | 1) => void;
}) {
  const [expanded, setExpanded] = useState(index === 0);
  const set = <K extends keyof Product>(key: K, value: Product[K]) => onChange({ ...product, [key]: value });
  const num = (v: string) => { const n = parseFloat(v); return Number.isFinite(n) && n >= 0 ? n : 0; };

  return (
    <div className="rounded-lg border border-outline-variant/60 bg-surface-container-low">
      <div className="flex items-center gap-3 p-3">
        <img src={product.image} alt="" className="h-12 w-12 shrink-0 rounded object-cover bg-surface-container" onError={(e) => { (e.currentTarget as HTMLImageElement).style.visibility = "hidden"; }} />
        <button type="button" onClick={() => setExpanded((v) => !v)} aria-expanded={expanded} className="min-w-0 flex-1 text-left">
          <span className="block truncate text-sm font-semibold text-primary">{product.name || "Untitled product"}</span>
          <span className="block text-[11px] font-mono-data text-secondary">₹{product.priceInr.toLocaleString("en-IN")} / ${product.priceUsd.toFixed(2)} per kg{product.samplePriceInr ? ` • Sample ₹${product.samplePriceInr}/50 g` : ""}{product.popular ? " • Featured" : ""}</span>
        </button>
        <div className="flex shrink-0 items-center gap-1">
          <button type="button" onClick={() => onMove(-1)} disabled={index === 0} aria-label="Move up" className="grid h-8 w-8 place-items-center rounded text-secondary hover:bg-surface-container disabled:opacity-30"><ChevronUp size={15} /></button>
          <button type="button" onClick={() => onMove(1)} disabled={index === total - 1} aria-label="Move down" className="grid h-8 w-8 place-items-center rounded text-secondary hover:bg-surface-container disabled:opacity-30"><ChevronDown size={15} /></button>
          <button type="button" onClick={onRemove} aria-label={`Remove ${product.name}`} className="grid h-8 w-8 place-items-center rounded text-error hover:bg-red-50"><Trash2 size={15} /></button>
          <button type="button" onClick={() => setExpanded((v) => !v)} aria-label={expanded ? "Collapse" : "Expand"} className="grid h-8 w-8 place-items-center rounded text-primary hover:bg-surface-container"><motion.span animate={{ rotate: expanded ? 180 : 0 }} className="grid"><ChevronDown size={16} /></motion.span></button>
        </div>
      </div>

      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.22 }} className="overflow-hidden">
            <div className="grid grid-cols-1 gap-3 border-t border-outline-variant/40 p-4 sm:grid-cols-2">
              <Field label="Product name" value={product.name} onChange={(v) => set("name", v)} />
              <Field label="Botanical name" value={product.botanical} onChange={(v) => set("botanical", v)} />
              <Field label="Price (INR per kg)" type="number" value={product.priceInr} onChange={(v) => set("priceInr", num(v))} />
              <Field label="Price (USD per kg)" type="number" value={product.priceUsd} onChange={(v) => set("priceUsd", num(v))} />
              <Field label="Sample price (INR per 50 g kit)" type="number" value={product.samplePriceInr ?? ""} onChange={(v) => set("samplePriceInr", num(v) || undefined)} hint="Leave 0 or blank to show samples as 'On request'." />
              <Field label="Sample price (USD per 50 g kit)" type="number" value={product.samplePriceUsd ?? ""} onChange={(v) => set("samplePriceUsd", num(v) || undefined)} hint="Optional. If blank, USD is estimated from the INR price." />
              <Field label="Standardized active (assay)" value={product.assay} onChange={(v) => set("assay", v)} placeholder="≥ 75.0% Gymnemic Acids" />
              <Field label="Plant part" value={product.part} onChange={(v) => set("part", v)} />
              <Field label="Physical appearance" value={product.appearance} onChange={(v) => set("appearance", v)} />
              <Field label="Loss on drying" value={product.lossOnDrying} onChange={(v) => set("lossOnDrying", v)} />
              <Field label="Batch number" value={product.batchNo} onChange={(v) => set("batchNo", v)} />
              <Field label="Stock (kg)" type="number" value={product.stockKg} onChange={(v) => set("stockKg", num(v))} />
              <Field label="Analytical method" value={product.standard} onChange={(v) => set("standard", v)} />
              <Field label="Heavy metals spec" value={product.heavyMetals} onChange={(v) => set("heavyMetals", v)} />
              <Field label="Microbial spec" value={product.microbial} onChange={(v) => set("microbial", v)} />
              <Field label="Solubility" value={product.solubility} onChange={(v) => set("solubility", v)} />
              <div className="sm:col-span-2">
                <Field label="Image URL" value={product.image} onChange={(v) => set("image", v)} hint="Use /images/your-file.jpg for a bundled photo, or a full https:// link." />
              </div>
              <div className="sm:col-span-2">
                <Field label="Applications (comma separated)" value={product.applications.join(", ")} onChange={(v) => set("applications", v.split(",").map((s) => s.trim()).filter(Boolean))} />
              </div>
              <Field label="Product ID (unique, no spaces)" value={product.id} onChange={(v) => set("id", v.toLowerCase().replace(/[^a-z0-9-]/g, "-"))} hint="Used internally for cart and links." />
              <label className="flex items-center gap-2 self-end pb-2 text-sm text-primary">
                <input type="checkbox" checked={!!product.popular} onChange={(e) => set("popular", e.target.checked)} className="h-4 w-4 accent-primary" />
                Show "High Demand Export" badge
              </label>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function AdminPanel({ open, config, onClose, onApply }: AdminPanelProps) {
  const [unlocked, setUnlocked] = useState(false);
  const [pinInput, setPinInput] = useState("");
  const [pinError, setPinError] = useState("");
  const [tab, setTab] = useState<Tab>("products");
  const [draft, setDraft] = useState<SiteConfig>(config);
  const [status, setStatus] = useState("");
  const [newPin, setNewPin] = useState("");
  const [confirmReset, setConfirmReset] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) { setDraft(config); setStatus(""); setPinInput(""); setPinError(""); setConfirmReset(false); }
  }, [open, config]);

  const dirty = useMemo(() => JSON.stringify({ p: draft.products, c: draft.contact }) !== JSON.stringify({ p: config.products, c: config.contact }), [draft, config]);

  const validation = useMemo(() => {
    const issues: string[] = [];
    const ids = new Set<string>();
    draft.products.forEach((p, i) => {
      if (!p.name.trim()) issues.push(`Product ${i + 1}: name is required.`);
      if (!p.id.trim()) issues.push(`Product ${i + 1}: ID is required.`);
      else if (ids.has(p.id)) issues.push(`Product "${p.name}": duplicate ID "${p.id}".`);
      ids.add(p.id);
      if (p.priceInr <= 0) issues.push(`Product "${p.name}": INR price must be greater than 0.`);
      if (p.priceUsd <= 0) issues.push(`Product "${p.name}": USD price must be greater than 0.`);
    });
    if (draft.products.length === 0) issues.push("At least one product is required.");
    const c = draft.contact;
    (["desk1", "whatsapp1"] as const).forEach((k) => { if (c[k].replace(/\D/g, "").length < 10) issues.push(`${k === "desk1" ? "Desk 1" : "WhatsApp 1"} needs a valid 10-digit number.`); });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email)) issues.push("Email address looks invalid.");
    c.salesWhatsapp.forEach((n, i) => {
      const d = n.replace(/\D/g, "");
      if (n.trim() && d.length < 10) issues.push(`Sales WhatsApp ${i + 1} needs a valid 10-digit number.`);
    });
    if (!c.salesWhatsapp.some((n) => n.replace(/\D/g, "").length >= 10)) issues.push("Add at least one Sales WhatsApp number to receive orders.");
    c.salesEmails.forEach((e, i) => { if (e.trim() && !isEmail(e)) issues.push(`Sales email ${i + 1} looks invalid.`); });
    return issues;
  }, [draft]);

  const unlock = (e: FormEvent) => {
    e.preventDefault();
    if (pinInput === loadPin()) { setUnlocked(true); setPinError(""); }
    else setPinError("Incorrect PIN.");
  };

  const setContact = <K extends keyof ContactInfo>(key: K, value: string) => setDraft((d) => ({ ...d, contact: { ...d.contact, [key]: value } }));
  const setProducts = (products: Product[]) => setDraft((d) => ({ ...d, products }));

  const handleSave = () => {
    if (validation.length) { setStatus("Fix the highlighted issues before saving."); return; }
    // Drop blank sales-number slots so the checkout only shows real recipients.
    const cleaned: SiteConfig = {
      ...draft,
      contact: {
        ...draft.contact,
        salesWhatsapp: draft.contact.salesWhatsapp.filter((n) => n.replace(/\D/g, "").length >= 10),
        salesEmails: draft.contact.salesEmails.map((e) => e.trim()).filter(isEmail),
      },
    };
    const saved = saveConfig(cleaned);
    onApply(saved);
    setStatus("Saved. The live site in this browser now shows your changes.");
  };

  const handleReset = () => {
    const base = resetConfig();
    setDraft(base);
    onApply(base);
    setConfirmReset(false);
    setStatus("Reset to the original built-in content.");
  };

  const handleExport = () => { downloadConfigJson(draft); setStatus("site-config.json downloaded."); };

  const handleImport = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = sanitizeConfig(JSON.parse(String(reader.result)));
        if (!parsed) throw new Error("bad");
        setDraft(parsed);
        setStatus("Imported. Review and press Save to apply.");
      } catch { setStatus("That file is not a valid site-config.json."); }
    };
    reader.readAsText(file);
  };

  const handleEmail = () => {
    if (validation.length) { setStatus("Fix the highlighted issues before emailing."); return; }
    downloadConfigJson(draft);
    window.location.href = configMailto(draft, draft.contact.email);
    setStatus("Your email app should open with the summary. Attach the downloaded site-config.json.");
  };

  const handleCopy = async () => {
    try { await navigator.clipboard.writeText(summarizeConfig(draft)); setStatus("Summary copied to clipboard."); }
    catch { setStatus("Clipboard unavailable — use Download instead."); }
  };

  const handleChangePin = () => {
    if (!/^\d{4,8}$/.test(newPin)) { setStatus("PIN must be 4 to 8 digits."); return; }
    savePin(newPin); setNewPin(""); setStatus("Admin PIN updated for this browser.");
  };

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: "products", label: "Products & prices", icon: <Package size={15} aria-hidden="true" /> },
    { key: "contact", label: "Contact numbers", icon: <Phone size={15} aria-hidden="true" /> },
    { key: "publish", label: "Save, backup & email", icon: <Mail size={15} aria-hidden="true" /> },
  ];

  return (
    <AnimatePresence>
      {open && (
        <Dialog key="admin" labelId="admin-heading" descriptionId="admin-description" onClose={onClose}>
          <div className="flex max-h-[90dvh] flex-col">
            {/* Header */}
            <div className="flex items-start justify-between gap-4 border-b border-outline-variant/50 px-5 py-5 sm:px-8">
              <div>
                <span className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-secondary"><Settings size={14} aria-hidden="true" /> Site admin</span>
                <h2 id="admin-heading" tabIndex={-1} data-dialog-heading className="mt-1.5 font-display-lg text-2xl font-medium text-primary outline-none">Edit website content</h2>
                <p id="admin-description" className="mt-1 text-xs leading-5 text-on-surface-variant">Products, prices, desk and WhatsApp numbers. Changes apply instantly in this browser and can be emailed as a backup.</p>
              </div>
              <button type="button" onClick={onClose} aria-label="Close admin panel" className="interactive-button grid h-10 w-10 shrink-0 place-items-center rounded-full border border-outline-variant/50 text-primary hover:bg-surface-container-high"><X size={18} aria-hidden="true" /></button>
            </div>

            {!unlocked ? (
              <form onSubmit={unlock} className="px-5 py-10 sm:px-8">
                <div className="mx-auto max-w-sm text-center">
                  <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary text-tertiary-fixed"><LockKeyhole size={24} aria-hidden="true" /></div>
                  <h3 className="mt-5 font-display-lg text-xl text-primary">Enter admin PIN</h3>
                  <p className="mt-2 text-xs text-on-surface-variant">Default PIN is <span className="font-mono-data font-semibold">2024</span>. You can change it inside the panel.</p>
                  <input autoFocus type="password" inputMode="numeric" value={pinInput} onChange={(e) => { setPinInput(e.target.value); setPinError(""); }} aria-label="Admin PIN" aria-invalid={!!pinError} className={`${inputCls} mt-5 text-center font-mono-data text-lg tracking-[0.4em]`} maxLength={8} />
                  {pinError && <p role="alert" className="mt-2 text-xs text-error">{pinError}</p>}
                  <button type="submit" className="interactive-button mt-4 flex min-h-11 w-full items-center justify-center gap-2 rounded bg-primary text-sm font-semibold text-white"><KeyRound size={15} aria-hidden="true" /> Unlock</button>
                  <p className="mt-6 flex items-start gap-2 text-left text-[11px] leading-5 text-outline"><AlertTriangle size={14} className="mt-0.5 shrink-0 text-tertiary" aria-hidden="true" />This PIN only deters casual visitors. The website is a static file with no server, so it is not real security — anyone can bypass it. Never store passwords or private data here.</p>
                </div>
              </form>
            ) : (
              <>
                {/* Tabs */}
                <div className="flex gap-1 overflow-x-auto border-b border-outline-variant/50 px-5 sm:px-8" role="tablist">
                  {tabs.map((t) => (
                    <button key={t.key} type="button" role="tab" aria-selected={tab === t.key} onClick={() => setTab(t.key)} className={`flex min-h-11 shrink-0 items-center gap-1.5 border-b-2 px-3 text-xs font-semibold transition-colors ${tab === t.key ? "border-tertiary text-primary" : "border-transparent text-on-surface-variant hover:text-primary"}`}>
                      {t.icon}{t.label}
                    </button>
                  ))}
                </div>

                {/* Body */}
                <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5 sm:px-8">
                  {tab === "products" && (
                    <div className="space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <p className="text-xs text-on-surface-variant">{draft.products.length} {draft.products.length === 1 ? "product" : "products"}. Click a name to expand and edit.</p>
                        <button type="button" onClick={() => setProducts([newProductTemplate(), ...draft.products])} className="interactive-button inline-flex min-h-10 items-center gap-1.5 rounded bg-primary px-4 text-xs font-semibold text-white"><Plus size={14} aria-hidden="true" /> Add product</button>
                      </div>
                      {draft.products.map((p, i) => (
                        <ProductEditor
                          key={`${i}-${p.id}`}
                          product={p}
                          index={i}
                          total={draft.products.length}
                          onChange={(np) => setProducts(draft.products.map((x, j) => (j === i ? np : x)))}
                          onRemove={() => setProducts(draft.products.filter((_, j) => j !== i))}
                          onMove={(dir) => {
                            const next = [...draft.products];
                            const target = i + dir;
                            if (target < 0 || target >= next.length) return;
                            [next[i], next[target]] = [next[target], next[i]];
                            setProducts(next);
                          }}
                        />
                      ))}
                    </div>
                  )}

                  {tab === "contact" && (
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div className="sm:col-span-2"><Field label="Company name" value={draft.contact.companyName} onChange={(v) => setContact("companyName", v)} /></div>
                      <Field label="Desk number 1" type="tel" value={draft.contact.desk1} onChange={(v) => setContact("desk1", v)} hint={`Shows as ${formatPhone(draft.contact.desk1) || "—"}`} />
                      <Field label="Desk number 2" type="tel" value={draft.contact.desk2} onChange={(v) => setContact("desk2", v)} hint={`Shows as ${formatPhone(draft.contact.desk2) || "—"}`} />
                      <Field label="WhatsApp number 1" type="tel" value={draft.contact.whatsapp1} onChange={(v) => setContact("whatsapp1", v)} hint={`Opens wa.me/${draft.contact.whatsapp1.replace(/\D/g, "").length === 10 ? "91" : ""}${draft.contact.whatsapp1.replace(/\D/g, "")}`} />
                      <Field label="WhatsApp number 2" type="tel" value={draft.contact.whatsapp2} onChange={(v) => setContact("whatsapp2", v)} hint="Leave blank to hide the second WhatsApp button." />
                      <div className="sm:col-span-2"><Field label="Email address" type="email" value={draft.contact.email} onChange={(v) => setContact("email", v)} hint="Also used as the recipient for 'Email changes to me'." /></div>
                      <div className="sm:col-span-2 border-t border-outline-variant/40 pt-4">
                        <span className="text-xs font-semibold text-primary">Order alerts on WhatsApp</span>
                        <p className="mt-0.5 text-[11px] text-outline">After checkout, buyers are prompted to send their order to each of these numbers.</p>
                      </div>
                      {[0, 1, 2, 3].map((i) => (
                        <Field
                          key={i}
                          label={`Sales WhatsApp ${i + 1}${i >= 3 ? " (optional)" : ""}`}
                          type="tel"
                          value={draft.contact.salesWhatsapp[i] ?? ""}
                          onChange={(v) => {
                            const next = [...draft.contact.salesWhatsapp];
                            while (next.length <= i) next.push("");
                            next[i] = v;
                            setDraft((d) => ({ ...d, contact: { ...d.contact, salesWhatsapp: next } }));
                          }}
                          hint={draft.contact.salesWhatsapp[i] ? `Shows as ${formatPhone(draft.contact.salesWhatsapp[i])}` : "Leave blank to remove."}
                        />
                      ))}
                      <div className="sm:col-span-2 border-t border-outline-variant/40 pt-4">
                        <span className="text-xs font-semibold text-primary">Order alerts by email</span>
                        <p className="mt-0.5 text-[11px] text-outline">After checkout, buyers can email their order to all of these addresses at once.</p>
                      </div>
                      {[0, 1, 2, 3].map((i) => (
                        <Field
                          key={`email-${i}`}
                          label={`Sales email ${i + 1}${i >= 3 ? " (optional)" : ""}`}
                          type="email"
                          value={draft.contact.salesEmails[i] ?? ""}
                          onChange={(v) => {
                            const next = [...draft.contact.salesEmails];
                            while (next.length <= i) next.push("");
                            next[i] = v;
                            setDraft((d) => ({ ...d, contact: { ...d.contact, salesEmails: next } }));
                          }}
                          hint={i === 0 ? "Leave blank to remove." : undefined}
                        />
                      ))}
                      <div className="sm:col-span-2 border-t border-outline-variant/40 pt-4"><span className="text-xs font-semibold text-primary">Factory address</span></div>
                      <Field label="Address line 1" value={draft.contact.addressLine1} onChange={(v) => setContact("addressLine1", v)} />
                      <Field label="Address line 2" value={draft.contact.addressLine2} onChange={(v) => setContact("addressLine2", v)} />
                      <Field label="City / town" value={draft.contact.city} onChange={(v) => setContact("city", v)} />
                      <Field label="PIN code" value={draft.contact.postalCode} onChange={(v) => setContact("postalCode", v)} />
                      <Field label="District / State" value={draft.contact.region} onChange={(v) => setContact("region", v)} />
                      <Field label="Working hours" value={draft.contact.hours} onChange={(v) => setContact("hours", v)} />
                    </div>
                  )}

                  {tab === "publish" && (
                    <div className="space-y-6">
                      <div className="rounded-lg border border-tertiary/40 bg-tertiary/5 p-4 text-xs leading-5 text-on-surface">
                        <p className="font-semibold text-primary">How saving works</p>
                        <ul className="mt-2 list-disc space-y-1 pl-4 text-on-surface-variant">
                          <li><strong>Save</strong> applies changes instantly, but only in <em>this</em> browser (stored locally). Other visitors still see the built-in content.</li>
                          <li><strong>Email changes to me</strong> opens your mail app with a summary addressed to <span className="font-mono-data">{draft.contact.email}</span> and downloads <span className="font-mono-data">site-config.json</span> to attach. This site has no server, so it cannot send mail by itself.</li>
                          <li>To make changes live for everyone, send the JSON to whoever deploys the site — it drops straight into <span className="font-mono-data">src/lib/siteConfig.ts</span> — or import it on any device via <strong>Import JSON</strong>.</li>
                        </ul>
                      </div>

                      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                        <button type="button" onClick={handleEmail} className="interactive-button flex min-h-12 items-center justify-center gap-2 rounded bg-primary px-4 text-sm font-semibold text-white"><Mail size={16} aria-hidden="true" /> Email changes to me</button>
                        <button type="button" onClick={handleCopy} className="interactive-button flex min-h-12 items-center justify-center gap-2 rounded border border-outline-variant px-4 text-sm font-semibold text-primary hover:bg-surface-container"><Copy size={15} aria-hidden="true" /> Copy summary</button>
                        <button type="button" onClick={handleExport} className="interactive-button flex min-h-12 items-center justify-center gap-2 rounded border border-outline-variant px-4 text-sm font-semibold text-primary hover:bg-surface-container"><Download size={15} aria-hidden="true" /> Export JSON backup</button>
                        <button type="button" onClick={() => fileRef.current?.click()} className="interactive-button flex min-h-12 items-center justify-center gap-2 rounded border border-outline-variant px-4 text-sm font-semibold text-primary hover:bg-surface-container"><Upload size={15} aria-hidden="true" /> Import JSON</button>
                        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={(e) => { handleImport(e.target.files?.[0]); e.target.value = ""; }} />
                      </div>

                      <details className="rounded-lg border border-outline-variant/50 bg-surface-container-low p-4 text-xs">
                        <summary className="cursor-pointer font-semibold text-primary">Preview email summary</summary>
                        <pre className="mt-3 max-h-64 overflow-auto whitespace-pre-wrap font-mono-data text-[11px] leading-5 text-on-surface-variant">{summarizeConfig(draft)}</pre>
                      </details>

                      <div className="border-t border-outline-variant/40 pt-5">
                        <span className="text-xs font-semibold text-primary">Change admin PIN</span>
                        <div className="mt-2 flex gap-2">
                          <input type="password" inputMode="numeric" value={newPin} onChange={(e) => setNewPin(e.target.value)} placeholder="New 4–8 digit PIN" aria-label="New admin PIN" className={`${inputCls} max-w-xs font-mono-data`} maxLength={8} />
                          <button type="button" onClick={handleChangePin} className="interactive-button inline-flex min-h-10 items-center gap-1.5 rounded border border-outline-variant px-4 text-xs font-semibold text-primary hover:bg-surface-container"><KeyRound size={14} aria-hidden="true" /> Update</button>
                        </div>
                      </div>

                      <div className="border-t border-outline-variant/40 pt-5">
                        <span className="text-xs font-semibold text-primary">Danger zone</span>
                        {!confirmReset ? (
                          <button type="button" onClick={() => setConfirmReset(true)} className="mt-2 inline-flex min-h-10 items-center gap-1.5 rounded border border-error/40 px-4 text-xs font-semibold text-error hover:bg-red-50"><RotateCcw size={14} aria-hidden="true" /> Reset to original content</button>
                        ) : (
                          <div className="mt-2 flex flex-wrap items-center gap-2 rounded border border-error/40 bg-red-50 p-3 text-xs text-error">
                            <span className="font-semibold">Discard all edits and restore the built-in products and contacts?</span>
                            <button type="button" onClick={handleReset} className="min-h-9 rounded bg-error px-3 font-semibold text-white">Yes, reset</button>
                            <button type="button" onClick={() => setConfirmReset(false)} className="min-h-9 rounded border border-error/40 px-3 font-semibold">Cancel</button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer */}
                <div className="shrink-0 border-t border-outline-variant/60 bg-surface-container-low px-5 py-4 sm:px-8">
                  {validation.length > 0 && (
                    <ul role="alert" className="mb-3 max-h-24 space-y-0.5 overflow-y-auto text-[11px] text-error">
                      {validation.map((v) => <li key={v} className="flex items-start gap-1.5"><AlertTriangle size={12} className="mt-0.5 shrink-0" aria-hidden="true" />{v}</li>)}
                    </ul>
                  )}
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <p role="status" className="min-h-5 text-xs text-on-surface-variant">{status || (dirty ? "You have unsaved changes." : draft.updatedAt ? `Last saved ${new Date(draft.updatedAt).toLocaleString("en-IN")}` : "Showing built-in content.")}</p>
                    <div className="flex items-center gap-2">
                      <button type="button" onClick={() => { setDraft(config); setStatus("Reverted unsaved changes."); }} disabled={!dirty} className="inline-flex min-h-10 items-center gap-1.5 rounded border border-outline-variant px-4 text-xs font-semibold text-primary hover:bg-surface-container disabled:opacity-40">Discard</button>
                      <button type="button" onClick={handleSave} disabled={!dirty || validation.length > 0} className="interactive-button inline-flex min-h-10 items-center gap-1.5 rounded bg-primary px-5 text-xs font-semibold text-white disabled:opacity-40">{dirty ? <Save size={14} aria-hidden="true" /> : <Check size={14} aria-hidden="true" />} {dirty ? "Save changes" : "Saved"}</button>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </Dialog>
      )}
    </AnimatePresence>
  );
}
