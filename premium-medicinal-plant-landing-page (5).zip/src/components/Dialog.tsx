import { useEffect, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { motion, useReducedMotion } from "framer-motion";

let openDialogCount = 0;
let previousBodyOverflow = "";

interface DialogProps {
  children: ReactNode;
  labelId: string;
  descriptionId?: string;
  onClose: () => void;
  drawer?: boolean;
}

export function Dialog({ children, labelId, descriptionId, onClose, drawer = false }: DialogProps) {
  const ref = useRef<HTMLDialogElement>(null);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const previousFocus = document.activeElement as HTMLElement | null;
    if (openDialogCount === 0) previousBodyOverflow = document.body.style.overflow;
    openDialogCount += 1;
    document.body.style.overflow = "hidden";
    element.showModal();
    const frame = requestAnimationFrame(() => {
      (element.querySelector<HTMLElement>("[data-dialog-heading]") ?? element).focus({ preventScroll: true });
    });
    return () => {
      cancelAnimationFrame(frame);
      element.close();
      openDialogCount -= 1;
      if (openDialogCount === 0) {
        document.body.style.overflow = previousBodyOverflow;
        if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
      }
    };
  }, []);

  return createPortal(
    <motion.dialog
      ref={ref}
      aria-labelledby={labelId}
      aria-describedby={descriptionId}
      aria-modal="true"
      className={`app-dialog ${drawer ? "drawer-dialog" : ""}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: reduceMotion ? 0 : 0.22 }}
      onCancel={(event) => { event.preventDefault(); onClose(); }}
      onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}
    >
      <motion.div
        className={`dialog-panel ${drawer ? "drawer-panel" : "center-panel"}`}
        initial={reduceMotion ? false : drawer ? { x: "100%" } : { y: 18, scale: 0.98 }}
        animate={{ x: 0, y: 0, scale: 1 }}
        exit={reduceMotion ? undefined : drawer ? { x: "100%" } : { y: 18, scale: 0.98 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      >
        {children}
      </motion.div>
    </motion.dialog>,
    document.body,
  );
}