import { useEffect, useRef, useState } from "react";
import { useReducedMotion } from "framer-motion";
import * as THREE from "three";

export function BotanicalCanvas({ paused = false }: { paused?: boolean }) {
  const mountRef = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();
  const pausedRef = useRef(paused || !!reduceMotion);
  const playbackRef = useRef<(() => void) | null>(null);
  const [unavailable, setUnavailable] = useState(false);

  useEffect(() => {
    pausedRef.current = paused || !!reduceMotion;
    playbackRef.current?.();
  }, [paused, reduceMotion]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let animationFrameId = 0;
    const scene = new THREE.Scene();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.z = 12;
    camera.position.y = 3.8;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "low-power" });
    } catch {
      setUnavailable(true);
      return;
    }
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    container.appendChild(renderer.domElement);
    scene.position.x = width > 900 ? 5.4 : 1.8;

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xc9a227, 1.2);
    dirLight.position.set(6, 12, 6);
    scene.add(dirLight);

    const goldPoint = new THREE.PointLight(0xffe08e, 1.5, 30);
    goldPoint.position.set(0, 4, 3);
    scene.add(goldPoint);

    // Trunk
    const trunkMaterial = new THREE.MeshPhongMaterial({ color: 0x4a3726, shininess: 15 });
    const trunkGeometry = new THREE.CylinderGeometry(0.38, 0.75, 8.2, 14);
    const trunk = new THREE.Mesh(trunkGeometry, trunkMaterial);
    trunk.position.y = -0.1;
    scene.add(trunk);

    // Botanical leaves / active nodes
    const leaves: {
      mesh: THREE.Mesh;
      initialPos: THREE.Vector3;
      speed: number;
      orbitSpeed: number;
      orbitRadius: number;
    }[] = [];

    const leafMaterial = new THREE.MeshPhongMaterial({
      color: 0x1f3d22,
      transparent: true,
      opacity: 0.92,
      side: THREE.DoubleSide,
      shininess: 30,
    });

    const goldLeafMat = new THREE.MeshPhongMaterial({
      color: 0xd4af37,
      transparent: true,
      opacity: 0.88,
      side: THREE.DoubleSide,
      shininess: 60,
    });

    const leafGeo = new THREE.SphereGeometry(0.48, 10, 10);
    const leafCount = 140;

    for (let i = 0; i < leafCount; i++) {
      const isGold = i % 7 === 0;
      const leaf = new THREE.Mesh(leafGeo, isGold ? goldLeafMat : leafMaterial);
      const phi = Math.acos(-1 + (2 * i) / leafCount);
      const theta = Math.sqrt(leafCount * Math.PI) * phi;
      const radius = 3.2 + Math.random() * 0.8;

      const x = radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.cos(phi) + 4.9;
      const z = radius * Math.sin(phi) * Math.sin(theta);

      leaf.position.set(x, y, z);
      const s = Math.random() * 0.45 + 0.45;
      leaf.scale.set(s, s * 0.75, s);

      leaves.push({
        mesh: leaf,
        initialPos: leaf.position.clone(),
        speed: Math.random() * 2 + 1,
        orbitSpeed: (Math.random() - 0.5) * 0.005,
        orbitRadius: Math.sqrt(x * x + z * z),
      });

      scene.add(leaf);
    }

    // Roots
    for (let i = 0; i < 8; i++) {
      const rootGeo = new THREE.CylinderGeometry(0.24, 0.04, 3.8, 8);
      const root = new THREE.Mesh(rootGeo, trunkMaterial);
      root.rotation.z = Math.PI / 2 + (Math.random() - 0.5) * 0.25;
      root.rotation.y = (i / 8) * Math.PI * 2;
      root.position.y = -3.8;
      scene.add(root);
    }

    // Glowing Bioactive particles
    const partCount = 280;
    const partGeo = new THREE.BufferGeometry();
    const posArray = new Float32Array(partCount * 3);
    for (let i = 0; i < partCount * 3; i += 3) {
      posArray[i] = (Math.random() - 0.5) * 18;
      posArray[i + 1] = Math.random() * 12 - 2;
      posArray[i + 2] = (Math.random() - 0.5) * 18;
    }
    partGeo.setAttribute("position", new THREE.BufferAttribute(posArray, 3));
    const partMat = new THREE.PointsMaterial({
      color: 0xffe08e,
      size: 0.075,
      transparent: true,
      opacity: 0.75,
    });
    const particles = new THREE.Points(partGeo, partMat);
    scene.add(particles);

    // Pointer response stays local to the hero, not the rest of the page.
    let mouseX = 0;
    let mouseY = 0;
    const hero = container.closest("section") ?? container;
    const handleMouseMove = (e: PointerEvent) => {
      if (pausedRef.current || e.pointerType === "touch") return;
      const bounds = hero.getBoundingClientRect();
      mouseX = ((e.clientX - bounds.left) / bounds.width - 0.5) * 0.6;
      mouseY = ((e.clientY - bounds.top) / bounds.height - 0.5) * 0.4;
    };
    const handlePointerLeave = () => { mouseX = 0; mouseY = 0; };
    hero.addEventListener("pointermove", handleMouseMove as EventListener, { passive: true });
    hero.addEventListener("pointerleave", handlePointerLeave);

    let inView = true;
    let elapsed = 0;
    let lastFrame = 0;
    const shouldAnimate = () => !pausedRef.current && inView && !document.hidden;

    const animate = (timestamp: number) => {
      animationFrameId = 0;
      if (!shouldAnimate()) return;
      elapsed += lastFrame ? Math.min((timestamp - lastFrame) / 1000, 0.05) : 0;
      lastFrame = timestamp;
      const time = elapsed;

      leaves.forEach((item) => {
        item.mesh.position.x = item.initialPos.x + Math.sin(time * item.speed) * 0.12;
        item.mesh.position.y = item.initialPos.y + Math.cos(time * item.speed) * 0.12;
      });

      particles.rotation.y = time * 0.04;
      particles.position.y = Math.sin(time * 0.45) * 0.35;

      // Gentle interactive sway
      scene.rotation.y = THREE.MathUtils.lerp(scene.rotation.y, Math.sin(time * 0.2) * 0.22 + mouseX * 0.5, 0.035);
      scene.rotation.x = THREE.MathUtils.lerp(scene.rotation.x, mouseY * 0.2, 0.035);

      renderer.render(scene, camera);
      animationFrameId = requestAnimationFrame(animate);
    };

    const updatePlayback = () => {
      cancelAnimationFrame(animationFrameId);
      animationFrameId = 0;
      lastFrame = 0;
      if (shouldAnimate()) animationFrameId = requestAnimationFrame(animate);
    };
    playbackRef.current = updatePlayback;
    renderer.render(scene, camera);
    updatePlayback();

    // Suspend GPU work while the hero or browser tab is not visible.
    const observer = new IntersectionObserver(([entry]) => {
      inView = entry.isIntersecting;
      updatePlayback();
    });
    observer.observe(container);
    document.addEventListener("visibilitychange", updatePlayback);

    const handleResize = () => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (!w || !h) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      scene.position.x = w > 900 ? 5.4 : 1.8;
      renderer.setSize(w, h);
      renderer.render(scene, camera);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      hero.removeEventListener("pointermove", handleMouseMove as EventListener);
      hero.removeEventListener("pointerleave", handlePointerLeave);
      document.removeEventListener("visibilitychange", updatePlayback);
      observer.disconnect();
      playbackRef.current = null;
      cancelAnimationFrame(animationFrameId);
      const geometries = new Set<THREE.BufferGeometry>();
      const materials = new Set<THREE.Material>();
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points) {
          geometries.add(object.geometry);
          (Array.isArray(object.material) ? object.material : [object.material]).forEach((material) => materials.add(material));
        }
      });
      geometries.forEach((geometry) => geometry.dispose());
      materials.forEach((material) => material.dispose());
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div className="relative h-full w-full pointer-events-none"><div ref={mountRef} className="h-full w-full" />{unavailable && <img src="/images/phytoo-hero.png" alt="" className="absolute inset-0 h-full w-full object-cover opacity-50" />}</div>;
}
