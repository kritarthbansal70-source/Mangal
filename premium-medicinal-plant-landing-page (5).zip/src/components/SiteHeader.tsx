import { useEffect, useState } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useReducedMotion, useScroll, useSpring } from "framer-motion";
import { ArrowRight, Leaf, Menu, ShoppingBag, X } from "lucide-react";
import type { Currency } from "../lib/commerce";

const LINKS = [
  { id: "hero", label: "Home" },
  { id: "products", label: "Products" },
  { id: "process", label: "Our process" },
  { id: "calculator", label: "Pricing" },
  { id: "quality", label: "Quality" },
  { id: "contact", label: "Contact" },
];

export function SiteHeader({ currency, onCurrencyChange, itemCount, onOpenCart }: {
  currency: Currency;
  onCurrencyChange: (value: Currency) => void;
  itemCount: number;
  onOpenCart: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");
  const [scrolled, setScrolled] = useState(false);
  const { scrollY, scrollYProgress } = useScroll();
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 160, damping: 30, restDelta: 0.001 });
  const reducedMotion = useReducedMotion();

  useMotionValueEvent(scrollY, "change", (y) => {
    setScrolled(y > 50);
    let active = "hero";
    for (const link of LINKS) {
      if ((document.getElementById(link.id)?.getBoundingClientRect().top ?? Infinity) <= window.innerHeight * 0.35) active = link.id;
    }
    setActiveSection(active);
  });

  useEffect(() => {
    const media = window.matchMedia("(min-width: 1280px)");
    const handleBreakpoint = () => { if (media.matches) setMenuOpen(false); };
    const handleEscape = (event: KeyboardEvent) => { if (event.key === "Escape") setMenuOpen(false); };
    media.addEventListener("change", handleBreakpoint);
    window.addEventListener("keydown", handleEscape);
    return () => { media.removeEventListener("change", handleBreakpoint); window.removeEventListener("keydown", handleEscape); };
  }, []);

  const currencyControl = (mobile = false) => (
    <div className={`items-center gap-0.5 rounded border border-white/15 p-0.5 ${mobile ? "flex" : "hidden sm:flex"}`} role="group" aria-label="Display currency">
      {(["INR", "USD"] as const).map((value) => (
        <button key={value} type="button" onClick={() => onCurrencyChange(value)} aria-pressed={currency === value} className={`min-h-8 rounded-sm px-2.5 font-mono-data text-[10px] transition-colors ${currency === value ? "bg-tertiary-fixed text-primary" : "text-on-primary/70 hover:text-white"}`}>
          {value === "INR" ? "INR" : "USD"}
        </button>
      ))}
    </div>
  );

  return (
    <header className={`sticky top-0 z-40 border-b border-white/10 bg-primary/95 backdrop-blur-xl transition-shadow duration-300 ${scrolled ? "shadow-[0_6px_28px_#00000025]" : ""}`}>
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <a href="#hero" aria-label="Manglam Phytoo Exploration home" className="group flex min-w-0 items-center gap-2.5 sm:gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded border border-tertiary-fixed/40 bg-tertiary/20 text-tertiary-fixed transition-colors group-hover:bg-tertiary/60"><Leaf size={21} strokeWidth={1.5} aria-hidden="true" /></span>
          <span className="min-w-0">
            <span className="block whitespace-nowrap font-display-lg text-base font-medium tracking-tight text-white sm:text-xl">Manglam Phytoo</span>
            <span className="mt-0.5 hidden min-[380px]:block text-[8px] uppercase tracking-[0.2em] text-tertiary-fixed/80 sm:text-[9px]">Exploration &amp; phytochemicals</span>
          </span>
        </a>
        <nav className="hidden items-center gap-6 xl:flex" aria-label="Primary navigation">
          {LINKS.map((link) => <a key={link.id} href={`#${link.id}`} aria-current={activeSection === link.id ? "location" : undefined} className={`nav-link text-[13px] font-medium transition-colors hover:text-tertiary-fixed ${activeSection === link.id ? "text-tertiary-fixed" : "text-white/75"}`}>{link.label}</a>)}
        </nav>
        <div className="flex shrink-0 items-center gap-2 sm:gap-4">
          {currencyControl()}
          <button type="button" onClick={() => { setMenuOpen(false); onOpenCart(); }} aria-label={`Open cart, ${itemCount} ${itemCount === 1 ? "selection" : "selections"}`} className="interactive-button relative grid h-10 w-10 place-items-center rounded border border-white/15 text-white hover:bg-white/10">
            <ShoppingBag size={18} strokeWidth={1.6} aria-hidden="true" />
            <AnimatePresence mode="wait">
              {itemCount > 0 && <motion.span key={itemCount} initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.6, opacity: 0 }} className="absolute -right-1.5 -top-1.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-tertiary-fixed px-1 text-[10px] font-semibold text-primary">{itemCount}</motion.span>}
            </AnimatePresence>
          </button>
          <button type="button" onClick={() => setMenuOpen((current) => !current)} aria-expanded={menuOpen} aria-controls="mobile-navigation" aria-label={menuOpen ? "Close navigation" : "Open navigation"} className="grid h-10 w-10 place-items-center text-white xl:hidden">{menuOpen ? <X size={21} /> : <Menu size={21} />}</button>
        </div>
      </div>
      <AnimatePresence initial={false}>
        {menuOpen && <motion.div id="mobile-navigation" initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: reducedMotion ? 0 : 0.25 }} className="overflow-hidden border-t border-white/10 bg-primary xl:hidden">
          <nav aria-label="Mobile navigation" className="max-h-[calc(100dvh-110px)] overflow-y-auto px-5 pb-6 pt-3">
            {LINKS.map((link) => <a key={link.id} href={`#${link.id}`} onClick={() => setMenuOpen(false)} aria-current={activeSection === link.id ? "location" : undefined} className={`flex min-h-12 items-center justify-between border-b border-white/10 text-sm ${activeSection === link.id ? "text-tertiary-fixed" : "text-white/80"}`}>{link.label}<ArrowRight size={14} aria-hidden="true" /></a>)}
            <div className="mt-5 flex items-center justify-between"><span className="text-xs text-white/65">Display currency</span>{currencyControl(true)}</div>
          </nav>
        </motion.div>}
      </AnimatePresence>
      <motion.div aria-hidden="true" className="absolute inset-x-0 -bottom-px h-[2px] origin-left bg-tertiary-fixed" style={{ scaleX: reducedMotion ? scrollYProgress : smoothProgress }} />
    </header>
  );
}